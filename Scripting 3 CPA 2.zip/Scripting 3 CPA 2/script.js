const character = document.getElementById("character");
const blocks = document.getElementsByClassName("block");

function StartGame()
{
    for (block of blocks)
    {
        block.style.animation = "block 5s infinite linear"
        let rect = block.getBoundingClientRect();
        if (rect.left >= 200)
        {
            block.style.animationDelay = "2.5s";
        }
    }
}

function Jump()
{
      let addedAnim = "";
     if(character.style.left == "0px" && character.classList.length == 0)
      {
         character.classList.add("animateright");
         character.style.left = "425px";
          addedAnim = "animateright";
      }
      else if (character.classList.length == 0)
      {
          character.classList.add("animateleft");
          character.style.left = "0px";
         addedAnim = "animateleft";
     }
     if (character.classList.contains(addedAnim))
     {
     setTimeout(function(){
     character.classList.remove(addedAnim)  
     },1000);
    }
}

let checkDead = setInterval(function(){
    let characterLeft = parseInt(character.style.left);
    for (block of blocks)
    {
        blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));
        blockTop = parseInt(window.getComputedStyle(block).getPropertyValue("top"));
        leftright = blockLeft - characterLeft;
        if (leftright >= 0 && leftright <= 25 && blockTop && blockTop >= 500 && blockTop <= 550)
        {
            alert("You Lose");
            for (block of blocks)
            {
            block.style.animation = "none";
            }
        }
    }
}, 10);